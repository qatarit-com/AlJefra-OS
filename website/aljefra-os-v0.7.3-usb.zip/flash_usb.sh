#!/bin/bash
# ================================================================
#  AlJefra OS v0.7.3 -- USB Flash Script for macOS
#  Automatically detects USB drive and flashes the ISO
# ================================================================

set -e

ISO="aljefra_os_v0.7.3.iso"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ISO_PATH="$SCRIPT_DIR/$ISO"

echo "================================================================"
echo "  AlJefra OS v0.7.3 -- USB Flash Tool"
echo "================================================================"
echo ""

# Check we're on macOS
if [[ "$(uname)" != "Darwin" ]]; then
    echo "This script is designed for macOS."
    echo "On Linux, use:  sudo dd if=$ISO of=/dev/sdX bs=4M status=progress"
    exit 1
fi

# Check ISO exists
if [[ ! -f "$ISO_PATH" ]]; then
    echo "ERROR: $ISO not found in $(pwd)"
    echo "Make sure $ISO is in the same directory as this script."
    exit 1
fi

# Check root
if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root (sudo)."
    echo "Usage: sudo ./flash_usb.sh"
    exit 1
fi

# List external disks
echo "Detecting USB drives..."
echo ""

# Find external/removable disks
DISKS=()
while IFS= read -r line; do
    disk=$(echo "$line" | awk '{print $1}')
    # Skip internal disk (usually disk0)
    if [[ "$disk" == "/dev/disk0" ]]; then
        continue
    fi
    # Check if it's external
    info=$(diskutil info "$disk" 2>/dev/null || true)
    if echo "$info" | grep -q "Removable Media.*Yes\|Protocol.*USB\|Location.*External"; then
        size=$(echo "$info" | grep "Disk Size" | head -1 | sed 's/.*: *//')
        name=$(echo "$info" | grep "Media Name" | head -1 | sed 's/.*: *//')
        DISKS+=("$disk")
        echo "  Found: $disk  ($name, $size)"
    fi
done < <(diskutil list | grep "^/dev/disk" | grep -v "synthesized")

echo ""

if [[ ${#DISKS[@]} -eq 0 ]]; then
    echo "No USB drives detected."
    echo "Please insert a USB drive and try again."
    exit 1
fi

# If multiple disks, let user choose
if [[ ${#DISKS[@]} -eq 1 ]]; then
    TARGET="${DISKS[0]}"
else
    echo "Multiple USB drives found. Select one:"
    for i in "${!DISKS[@]}"; do
        echo "  $((i+1)). ${DISKS[$i]}"
    done
    echo ""
    read -p "Enter number (1-${#DISKS[@]}): " choice
    idx=$((choice - 1))
    if [[ $idx -lt 0 || $idx -ge ${#DISKS[@]} ]]; then
        echo "Invalid selection."
        exit 1
    fi
    TARGET="${DISKS[$idx]}"
fi

# Show target info
echo "Target disk: $TARGET"
diskutil info "$TARGET" | grep -E "Disk Size|Media Name|Protocol" | sed 's/^/  /'
echo ""

# Get raw disk path (faster I/O on macOS)
RAW_TARGET=$(echo "$TARGET" | sed 's|/dev/disk|/dev/rdisk|')

# Confirm
echo "WARNING: ALL DATA ON $TARGET WILL BE ERASED!"
echo ""
read -p "Type 'yes' to continue: " confirm
if [[ "$confirm" != "yes" ]]; then
    echo "Aborted."
    exit 0
fi

# Unmount
echo ""
echo "Unmounting $TARGET..."
diskutil unmountDisk "$TARGET" 2>/dev/null || true

# Flash
ISO_SIZE=$(stat -f%z "$ISO_PATH" 2>/dev/null || stat -c%s "$ISO_PATH" 2>/dev/null)
echo "Flashing $ISO ($(( ISO_SIZE / 1024 )) KB) to $RAW_TARGET..."
echo "This may take 5-30 seconds..."
echo ""

dd if="$ISO_PATH" of="$RAW_TARGET" bs=4m 2>&1

# Sync and eject
sync
echo ""
echo "Ejecting $TARGET..."
diskutil eject "$TARGET" 2>/dev/null || true

echo ""
echo "================================================================"
echo "  Done! AlJefra OS v0.7.3 has been flashed to your USB drive."
echo ""
echo "  To boot:"
echo "    1. Insert USB into target machine"
echo "    2. Mac: Hold Option key at startup"
echo "       PC:  Press F12/F2/Del for boot menu"
echo "    3. Select the USB drive"
echo "================================================================"
