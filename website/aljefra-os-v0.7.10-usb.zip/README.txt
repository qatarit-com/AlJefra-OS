================================================================
  AlJefra OS v0.7.10 -- Bootable USB Image
  The First Qatari Operating System
  By Qatar IT (os.aljefra.com)
================================================================

This package contains a bootable ISO image of AlJefra OS v0.7.10.
You can flash it to a USB drive and boot it on any x86-64 PC/laptop.

CONTENTS
--------
  aljefra_os_v0.7.10.iso   Bootable ISO image (GRUB2 + Multiboot)
  flash_usb.sh          Automated flash script for macOS
  README.txt            This file

QUICK START (macOS)
-------------------
Option A: Use the automated script

  1. Insert your USB drive
  2. Open Terminal
  3. Run:  chmod +x flash_usb.sh && sudo ./flash_usb.sh
  4. The script will detect your USB, confirm, and flash

Option B: Manual steps

  1. Insert your USB drive
  2. Open Terminal
  3. Find your USB disk:
       diskutil list
     Look for your USB drive (e.g. /dev/disk2 or /dev/disk4).
     IMPORTANT: Make sure you identify the correct disk!

  4. Unmount the disk:
       diskutil unmountDisk /dev/diskN
     (replace N with your disk number)

  5. Flash the ISO:
       sudo dd if=aljefra_os_v0.7.10.iso of=/dev/rdiskN bs=4m
     (use rdiskN, not diskN -- rdisk is faster on macOS)
     This will take 5-30 seconds depending on USB speed.

  6. Eject:
       diskutil eject /dev/diskN

BOOTING
-------
  1. Insert the USB into your target laptop/PC
  2. Power on and enter BIOS/UEFI boot menu:
       - Mac: Hold Option key at startup
       - PC:  Press F12, F2, Del, or Esc during POST
  3. Select the USB drive from the boot menu
  4. GRUB will load and boot AlJefra OS automatically (3s timeout)
  5. The OS outputs to serial console (COM1, 115200 baud)

     For laptops without serial, the OS will still initialize all
     hardware. Connect a USB-to-serial adapter or use the VGA
     framebuffer output (if your machine has a VGA-compatible GPU).

QEMU TESTING (before flashing)
------------------------------
You can test the ISO in QEMU first:

  qemu-system-x86_64 -m 256 -cdrom aljefra_os_v0.7.10.iso -boot d \
    -serial mon:stdio -display none -device e1000,netdev=n0 \
    -netdev user,id=n0

WHAT TO EXPECT
--------------
AlJefra OS boots through these stages:
  1. GRUB bootloader (1 second hidden boot)
  2. HAL initialization (CPU, MMU, interrupts, PCIe, timer)
  3. Device scan (PCIe bus enumeration)
  4. Built-in driver loading (storage, network)
  5. DHCP network configuration
  6. AI Bootstrap (connects to AlJefra Store for drivers)
  7. "AlJefra OS ready." message

SPECIFICATIONS
--------------
  Architecture:    x86-64 (AMD64)
  Kernel size:     214 KB
  ISO size:        ~2.9 MB
  RAM required:    64 MB minimum, 256 MB recommended
  Boot protocol:   Multiboot1 via GRUB2
  Console:         Serial COM1 (115200 8N1) + VGA framebuffer
  Network:         Intel e1000/e1000e, VirtIO-Net, RTL8169
  Storage:         NVMe, AHCI/SATA, VirtIO-Blk, eMMC, UFS
  Drivers:         22+ built-in, runtime .ajdrv via marketplace

LICENSE
-------
AlJefra OS is released under the MIT License.
Copyright (c) 2026 Qatar IT / AlJefra

Website:  https://os.aljefra.com
Source:   https://github.com/qatarit-com/AlJefra-OS
================================================================
